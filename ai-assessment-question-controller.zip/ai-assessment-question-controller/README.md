
# AI Assessment Question Structure Controller

This project validates the structure of AI assessment questions before they are stored or used in an interview or testing system.

## Features
- Question structure validation
- Supports MCQ, TRUE_FALSE, and SHORT answer types
- JSON based input validation
- Unit test coverage using unittest

## Project Structure

ai-assessment-question-controller
│
├── controller
│   └── question_validator.py
│
├── tests
│   └── test_validator.py
│
├── README.md

## How to Run Tests

Install Python 3 and run:

python -m unittest discover tests

If all tests pass you will see:

Ran X tests
OK
