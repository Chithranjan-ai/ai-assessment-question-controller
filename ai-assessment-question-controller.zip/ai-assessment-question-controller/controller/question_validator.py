
class QuestionValidator:

    VALID_TYPES = ["MCQ", "TRUE_FALSE", "SHORT"]

    @staticmethod
    def validate(question_data):

        if not isinstance(question_data, dict):
            return False, "Input must be a dictionary"

        required_fields = ["question", "type"]

        for field in required_fields:
            if field not in question_data or not question_data[field]:
                return False, f"Missing or empty field: {field}"

        if question_data["type"] not in QuestionValidator.VALID_TYPES:
            return False, "Invalid question type"

        if question_data["type"] == "MCQ":

            if "options" not in question_data:
                return False, "MCQ must contain options"

            if not isinstance(question_data["options"], list):
                return False, "Options must be a list"

            if len(question_data["options"]) < 2:
                return False, "MCQ must have at least 2 options"

            if "answer" not in question_data:
                return False, "MCQ must contain answer"

            if question_data["answer"] not in question_data["options"]:
                return False, "Answer must be one of the options"

        if question_data["type"] == "TRUE_FALSE":
            if "answer" not in question_data:
                return False, "TRUE_FALSE must contain answer"
            if question_data["answer"] not in [True, False]:
                return False, "Answer must be True or False"

        if question_data["type"] == "SHORT":
            if "answer" not in question_data:
                return False, "SHORT type must contain answer"

        return True, "Question structure valid"
