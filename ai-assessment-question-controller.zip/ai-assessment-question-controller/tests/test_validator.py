
import unittest
from controller.question_validator import QuestionValidator


class TestQuestionValidator(unittest.TestCase):

    def test_valid_mcq(self):
        data = {
            "question": "What is AI?",
            "type": "MCQ",
            "options": ["Artificial Intelligence", "Database"],
            "answer": "Artificial Intelligence"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertTrue(result)

    def test_missing_question(self):
        data = {
            "type": "MCQ",
            "options": ["A", "B"],
            "answer": "A"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertFalse(result)

    def test_invalid_question_type(self):
        data = {
            "question": "What is AI?",
            "type": "LONG",
            "answer": "Artificial Intelligence"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertFalse(result)

    def test_mcq_without_options(self):
        data = {
            "question": "What is AI?",
            "type": "MCQ",
            "answer": "AI"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertFalse(result)

    def test_mcq_invalid_answer(self):
        data = {
            "question": "What is AI?",
            "type": "MCQ",
            "options": ["A", "B"],
            "answer": "C"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertFalse(result)

    def test_true_false_valid(self):
        data = {
            "question": "AI stands for Artificial Intelligence",
            "type": "TRUE_FALSE",
            "answer": True
        }
        result, _ = QuestionValidator.validate(data)
        self.assertTrue(result)

    def test_true_false_invalid_answer(self):
        data = {
            "question": "AI stands for Artificial Intelligence",
            "type": "TRUE_FALSE",
            "answer": "Yes"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertFalse(result)

    def test_short_answer_valid(self):
        data = {
            "question": "Define AI",
            "type": "SHORT",
            "answer": "Artificial Intelligence"
        }
        result, _ = QuestionValidator.validate(data)
        self.assertTrue(result)

    def test_invalid_input_type(self):
        data = "This is not JSON"
        result, _ = QuestionValidator.validate(data)
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
