
import unittest
from controller.assessment_controller import AssessmentQuestionController


def sample_questions():
    questions = [
        {"question": "Please introduce yourself.", "difficulty": 1}
    ]

    for i in range(2, 11):
        questions.append({
            "question": f"Domain question {i}",
            "difficulty": i
        })

    return questions


class TestAssessmentController(unittest.TestCase):

    def test_valid_structure(self):
        questions = sample_questions()
        result, _ = AssessmentQuestionController.validate(questions)
        self.assertTrue(result)

    def test_wrong_question_count(self):
        questions = sample_questions()[:5]
        result, _ = AssessmentQuestionController.validate(questions)
        self.assertFalse(result)

    def test_first_question_rule(self):
        questions = sample_questions()
        questions[0]["question"] = "Tell me about AI"
        result, _ = AssessmentQuestionController.validate(questions)
        self.assertFalse(result)

    def test_duplicate_questions(self):
        questions = sample_questions()
        questions[5]["question"] = questions[4]["question"]
        result, _ = AssessmentQuestionController.validate(questions)
        self.assertFalse(result)

    def test_difficulty_order(self):
        questions = sample_questions()
        questions[3]["difficulty"] = 10
        result, _ = AssessmentQuestionController.validate(questions)
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
