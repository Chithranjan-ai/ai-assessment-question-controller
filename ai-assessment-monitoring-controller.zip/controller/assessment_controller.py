
class AssessmentQuestionController:
    """
    Controller that validates AI assessment question structure.
    Rules:
    - Exactly 10 questions
    - First question must be 'Please introduce yourself.'
    - No duplicate questions
    - Difficulty must increase (1 → 10)
    """

    REQUIRED_COUNT = 10
    INTRO_QUESTION = "Please introduce yourself."

    @staticmethod
    def validate(questions):

        if not isinstance(questions, list):
            return False, "Questions must be a list"

        if len(questions) != AssessmentQuestionController.REQUIRED_COUNT:
            return False, "Assessment must contain exactly 10 questions"

        # First question validation
        if questions[0]["question"] != AssessmentQuestionController.INTRO_QUESTION:
            return False, "First question must be 'Please introduce yourself.'"

        # Check duplicates
        seen = set()
        for q in questions:
            if q["question"] in seen:
                return False, "Duplicate questions detected"
            seen.add(q["question"])

        # Difficulty order validation
        difficulties = [q["difficulty"] for q in questions]
        if difficulties != sorted(difficulties):
            return False, "Questions must follow increasing difficulty"

        return True, "Assessment structure valid"
