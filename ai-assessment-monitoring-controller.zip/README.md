
# AI Assessment Question Structure Controller

This module is part of the **AI Assessment Monitoring System**.

It ensures that every AI assessment follows a strict question structure.

## Rules Enforced

- Exactly **10 questions**
- First question must be: **"Please introduce yourself."**
- Remaining **9 questions are domain specific**
- Difficulty must increase gradually
- No duplicate questions allowed

## Project Structure

ai-assessment-monitoring-controller
│
├── controller
│   └── assessment_controller.py
│
├── tests
│   └── test_controller.py
│
└── README.md

## Run Tests

Open terminal in the project folder and run:

python -m unittest discover tests

Expected output:

Ran 5 tests
OK
