# AI Assessment Monitoring System

## Module: Assessment Question Structure Controller

Intern: Chithranjan Agapu
Internship: UpToSkills

This project ensures a fixed and fair structure for AI-based assessments.

### How to Run
pip install -r requirements.txt
python app.py
