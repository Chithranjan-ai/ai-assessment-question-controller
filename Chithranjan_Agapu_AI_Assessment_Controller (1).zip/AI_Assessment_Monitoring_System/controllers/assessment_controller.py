from data.question_bank import QUESTION_BANK
from utils.validator import validate_questions

def generate_assessment_questions(domain):
    questions = []

    questions.append("Please introduce yourself.")

    if domain not in QUESTION_BANK:
        return None

    for level in ["easy", "medium", "hard"]:
        questions.extend(QUESTION_BANK[domain][level])

    questions = questions[:10]

    if not validate_questions(questions):
        return None

    return questions
