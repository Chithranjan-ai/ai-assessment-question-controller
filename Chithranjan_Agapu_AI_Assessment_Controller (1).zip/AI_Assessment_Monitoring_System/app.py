from flask import Flask, request, jsonify
from controllers.assessment_controller import generate_assessment_questions

app = Flask(__name__)

@app.route("/generate-assessment", methods=["POST"])
def generate_assessment():
    data = request.get_json()

    if not data or "domain" not in data:
        return jsonify({"error": "Domain is required"}), 400

    domain = data["domain"]
    questions = generate_assessment_questions(domain)

    if questions is None:
        return jsonify({"error": "Assessment generation failed"}), 400

    return jsonify({
        "total_questions": len(questions),
        "questions": questions
    }), 200

if __name__ == "__main__":
    app.run(debug=True)
