QUESTION_BANK = {
    "AI_ML": {
        "easy": [
            "What is Machine Learning?",
            "What is supervised learning?",
            "What is unsupervised learning?"
        ],
        "medium": [
            "Explain overfitting in machine learning.",
            "What is bias and variance trade-off?",
            "Explain classification vs regression."
        ],
        "hard": [
            "Explain gradient descent algorithm.",
            "How does backpropagation work?",
            "Explain regularization techniques."
        ]
    },
    "Web_Development": {
        "easy": [
            "What is HTML?",
            "What is CSS?",
            "What is JavaScript?"
        ],
        "medium": [
            "Explain RESTful APIs.",
            "What is DOM?",
            "Explain client-server architecture."
        ],
        "hard": [
            "Explain middleware in web frameworks.",
            "What is event delegation?",
            "How does authentication work in web apps?"
        ]
    }
}
