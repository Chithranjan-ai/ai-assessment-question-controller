def validate_questions(questions):
    if len(questions) != 10:
        return False

    if questions[0] != "Please introduce yourself.":
        return False

    if len(set(questions)) != len(questions):
        return False

    return True
